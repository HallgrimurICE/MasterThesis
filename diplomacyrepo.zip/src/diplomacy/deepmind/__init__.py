# diplomacy/deepmind/__init__.py
from .build_observation import build_observation
from .actions import legal_actions_from_state
