# sl_agent.py

import numpy as np
from typing import List, Any, Dict

from run_sl import make_sl_policy
from environment import observation_utils as obs_utils
from environment import action_utils


class SlAgent:
    def __init__(self, sl_params_path: str, rng_seed: int = 0):
        self._policy = make_sl_policy(sl_params_path, rng_seed=rng_seed)

    def choose_orders(
        self,
        state,                      # your game state object
        players: List[int] = None,  # which powers to control, e.g. [0] or [0..6]
    ) -> Dict[int, Any]:
        """
        Given a game state, return chosen action indices per player.

        Returns:
            dict: {player_index: list_of_action_indices}
        """

        # 1) Build observation from your state
        # This must match DeepMind's Observation structure. If you're using their
        # environment code, there should be a helper something like:
        #   observation = obs_utils.observation_from_state(state)
        # or   obs_utils.build_observation(state, ...)
        #
        # TODO: replace with the actual function from observation_utils you use.
        observation = obs_utils.observation_from_state(state)

        # 2) Build legal actions per player from state
        # Again, use the helpers from action_utils that are in your repo.
        # Something like:
        #   legal_actions = action_utils.legal_actions_from_state(state)
        #
        # This should give: List[np.ndarray], length = num_players
        legal_actions = action_utils.legal_actions_from_state(state)

        num_players = len(legal_actions)
        if players is None:
            players = list(range(num_players))

        # 3) Ask the SL policy for actions
        actions, info = self._policy.actions(
            slots_list=players,
            observation=observation,
            legal_actions=legal_actions,
        )

        # 4) Pack into a nicer dict: {player: [indices]}
        result = {}
        for slot_idx, player in enumerate(players):
            result[player] = list(actions[slot_idx])

        return result, info
